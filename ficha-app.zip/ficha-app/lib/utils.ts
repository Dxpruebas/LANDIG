export const PLANS: Record<string, { key: string; label: string; price: number; extraButtons: number }> = {
  FREE: { key: "FREE", label: "Gratis", price: 0, extraButtons: 0 },
  BASICO: { key: "BASICO", label: "Negocio", price: 10, extraButtons: 1 },
  PRO: { key: "PRO", label: "Pro", price: 15, extraButtons: 3 },
};

export const ROLES: Record<string, { label: string; canManageUsers: boolean; canApprovePayments: boolean; canVerify: boolean }> = {
  ADMIN: { label: "Administrador", canManageUsers: true, canApprovePayments: true, canVerify: true },
  MODERADOR: { label: "Moderador", canManageUsers: false, canApprovePayments: true, canVerify: true },
  USER: { label: "Usuario", canManageUsers: false, canApprovePayments: false, canVerify: false },
};

export function addDays(date: Date, days: number) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

export function daysLeft(end: Date | string | null) {
  if (!end) return null;
  const endDate = new Date(end).getTime();
  const now = Date.now();
  return Math.round((endDate - now) / 86400000);
}

export function youtubeId(url: string) {
  if (!url) return null;
  try {
    const u = new URL(url.trim());
    if (u.hostname.includes("youtu.be")) return u.pathname.slice(1);
    if (u.searchParams.get("v")) return u.searchParams.get("v");
    const m = u.pathname.match(/\/embed\/([^/?]+)/);
    if (m) return m[1];
  } catch (e) {
    return null;
  }
  return null;
}

export function socialHref(kind: string, raw: string) {
  if (!raw) return "#";
  const v = raw.trim();
  if (kind === "whatsapp") {
    const digits = v.replace(/[^\d]/g, "");
    return v.startsWith("http") ? v : `https://wa.me/${digits}`;
  }
  if (kind === "instagram") return v.startsWith("http") ? v : `https://instagram.com/${v.replace("@", "")}`;
  if (kind === "telegram") return v.startsWith("http") ? v : `https://t.me/${v.replace("@", "")}`;
  return v;
}
