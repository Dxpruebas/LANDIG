"use client";
import React, { useState } from "react";
import { youtubeId } from "@/lib/utils";

export function ImageSlider({ images }: { images: (string | null)[] }) {
  const valid = images.filter(Boolean) as string[];
  const [i, setI] = useState(0);
  if (valid.length === 0)
    return (
      <div className="aspect-[4/3] w-full flex items-center justify-center text-sm bg-surface2 text-muted">
        Sin imágenes todavía
      </div>
    );
  return (
    <div className="relative">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={valid[i]} alt="" className="w-full aspect-[4/3] object-cover" />
      {valid.length > 1 && (
        <>
          <button
            onClick={() => setI((i - 1 + valid.length) % valid.length)}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/60 text-white text-sm font-bold backdrop-blur"
          >
            ‹
          </button>
          <button
            onClick={() => setI((i + 1) % valid.length)}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/60 text-white text-sm font-bold backdrop-blur"
          >
            ›
          </button>
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5">
            {valid.map((_, idx) => (
              <span key={idx} className="w-1.5 h-1.5 rounded-full" style={{ background: idx === i ? "#7C5CFC" : "rgba(255,255,255,0.6)" }} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export function VideoSlider({ videos }: { videos: string[] }) {
  const valid = videos.map(youtubeId).filter(Boolean) as string[];
  const [i, setI] = useState(0);
  if (valid.length === 0)
    return (
      <div className="aspect-video w-full flex items-center justify-center text-sm bg-surface2 text-muted">
        Sin videos todavía
      </div>
    );
  return (
    <div className="relative">
      <div className="aspect-video w-full bg-black">
        <iframe
          key={valid[i]}
          className="w-full h-full"
          src={`https://www.youtube.com/embed/${valid[i]}`}
          title="video"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
      {valid.length > 1 && (
        <div className="flex gap-1.5 justify-center py-2">
          {valid.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setI(idx)}
              className="w-2 h-2 rounded-full"
              style={{ background: idx === i ? "#7C5CFC" : "#262837" }}
            />
          ))}
        </div>
      )}
    </div>
  );
}
