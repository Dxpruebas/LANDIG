"use client";
import React from "react";
import { Check, Lock } from "lucide-react";

export function Button({
  children,
  onClick,
  variant = "primary",
  type = "button",
  disabled,
  className = "",
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "primary" | "outline" | "ghost" | "danger";
  type?: "button" | "submit";
  disabled?: boolean;
  className?: string;
}) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed active:scale-[0.98]";
  const styles: Record<string, string> = {
    primary: "bg-primary hover:bg-primary-dark text-white shadow-[0_4px_14px_rgba(124,92,252,0.35)]",
    outline: "border border-border text-ink hover:border-primary hover:text-primary",
    ghost: "text-ink hover:bg-surface2",
    danger: "bg-danger text-white hover:opacity-90",
  };
  return (
    <button type={type} disabled={disabled} onClick={onClick} className={`${base} ${styles[variant]} ${className}`}>
      {children}
    </button>
  );
}

export function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <label className="block mb-4">
      <span className="block text-xs font-semibold uppercase tracking-wide mb-1.5 text-muted">{label}</span>
      {children}
      {hint && <span className="block text-xs mt-1 text-muted">{hint}</span>}
    </label>
  );
}

export function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`input-base ${props.className || ""}`} />;
}

export function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={`input-base ${props.className || ""}`} />;
}

export function Badge({ children, tone = "neutral" }: { children: React.ReactNode; tone?: "neutral" | "good" | "warn" | "bad" }) {
  const tones: Record<string, string> = {
    neutral: "bg-surface2 text-ink",
    good: "bg-success/15 text-success",
    warn: "bg-warning/15 text-warning",
    bad: "bg-danger/15 text-danger",
  };
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold tracking-wide font-mono ${tones[tone]}`}>
      {children}
    </span>
  );
}

export function VerifiedBadge({ size = 16 }: { size?: number }) {
  return (
    <span
      title="Perfil verificado"
      className="inline-flex items-center justify-center rounded-full flex-shrink-0 bg-cyan"
      style={{ width: size, height: size }}
    >
      <Check size={size * 0.6} color="#0A0B10" strokeWidth={3} />
    </span>
  );
}

export function CheckToggleCard({
  icon,
  title,
  subtitle,
  checked,
  onChange,
  locked,
  children,
}: {
  icon?: React.ReactNode;
  title: string;
  subtitle?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  locked?: boolean;
  children?: React.ReactNode;
}) {
  return (
    <div
      className="rounded-2xl border transition-all"
      style={{
        borderColor: checked && !locked ? "#7C5CFC" : "#262837",
        background: checked && !locked ? "rgba(124,92,252,0.08)" : "#14151F",
        opacity: locked ? 0.55 : 1,
      }}
    >
      <button
        type="button"
        disabled={locked}
        onClick={() => onChange(!checked)}
        className="w-full flex items-center gap-3 px-4 py-3 text-left disabled:cursor-not-allowed"
      >
        {icon && (
          <span
            className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: checked && !locked ? "#7C5CFC" : "#1B1D29", color: checked && !locked ? "#fff" : "#8B8FA3" }}
          >
            {icon}
          </span>
        )}
        <span className="flex-1 min-w-0">
          <span className="block text-sm font-semibold text-ink">{title}</span>
          {subtitle && <span className="block text-xs mt-0.5 text-muted">{subtitle}</span>}
        </span>
        <span
          className="w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0 border-2"
          style={{
            borderColor: locked ? "#3A3D4D" : checked ? "#7C5CFC" : "#262837",
            background: locked ? "transparent" : checked ? "#7C5CFC" : "transparent",
          }}
        >
          {locked ? <Lock size={12} color="#3A3D4D" /> : checked ? <Check size={16} color="#fff" strokeWidth={3} /> : null}
        </span>
      </button>
      {checked && !locked && children && <div className="px-4 pb-4 -mt-1">{children}</div>}
    </div>
  );
}

export function SectionHeader({ icon, title, hint }: { icon: React.ReactNode; title: string; hint?: string }) {
  return (
    <div className="flex items-center gap-2 mb-3 mt-8 first:mt-0">
      <span className="w-7 h-7 rounded-lg flex items-center justify-center bg-surface2 text-ink">{icon}</span>
      <div>
        <p className="text-sm font-bold font-display text-ink">{title}</p>
        {hint && <p className="text-xs text-muted">{hint}</p>}
      </div>
    </div>
  );
}
