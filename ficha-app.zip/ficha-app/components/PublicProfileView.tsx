import React from "react";
import { MessageCircle, Instagram, Send } from "lucide-react";
import { ImageSlider, VideoSlider } from "./Sliders";
import { VerifiedBadge, Badge } from "./ui";
import { PLANS, socialHref } from "@/lib/utils";

type Social = { url: string; visible: boolean };
type ExtraButton = { id: string; label: string; url: string; visible: boolean };

export function PublicProfileView({ profile }: { profile: any }) {
  const social = (profile.social || {}) as Record<string, Social>;
  const extraButtons = (profile.extraButtons || []) as ExtraButton[];
  const planActive = profile.planStatus === "active";

  const socialItems = [
    { key: "whatsapp", label: "WhatsApp", icon: <MessageCircle size={14} />, color: "#22B658" },
    { key: "instagram", label: "Instagram", icon: <Instagram size={14} />, color: "#C13584" },
    { key: "telegram", label: "Telegram", icon: <Send size={14} />, color: "#229ED9" },
  ].filter((it) => social[it.key]?.visible && social[it.key]?.url);

  const visibleExtra = extraButtons.filter((b) => b.visible && b.label && b.url);

  return (
    <div className="max-w-md mx-auto px-4 py-8">
      <div className="rounded-[22px] overflow-hidden card">
        <ImageSlider images={[profile.photoUrl, ...(profile.images || [])]} />
        <div className="p-5">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h1 className="text-xl font-bold font-display flex items-center gap-1.5 text-ink">
                {profile.displayName}
                {profile.verified && <VerifiedBadge size={18} />}
              </h1>
              {profile.tagline && <p className="text-sm mt-0.5 text-muted">{profile.tagline}</p>}
            </div>
            {planActive && profile.planType !== "FREE" && <Badge tone="good">{PLANS[profile.planType].label}</Badge>}
          </div>
          {profile.description && <p className="text-sm mt-3 leading-relaxed text-ink">{profile.description}</p>}

          {socialItems.length > 0 && (
            <div className="flex gap-2 flex-wrap mt-4">
              {socialItems.map((it) => (
                <a
                  key={it.key}
                  href={socialHref(it.key, social[it.key].url)}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 rounded-full px-3.5 py-2 text-xs font-semibold text-white"
                  style={{ background: it.color }}
                >
                  {it.icon}
                  {it.label}
                </a>
              ))}
            </div>
          )}

          {planActive && visibleExtra.length > 0 && (
            <div className="flex flex-col gap-2 mt-4">
              {visibleExtra.map((b) => (
                <a
                  key={b.id}
                  href={b.url}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full text-center rounded-xl py-2.5 text-sm font-semibold border border-primary text-primary-light hover:bg-primary/10"
                >
                  {b.label}
                </a>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="mt-6">
        <p className="text-xs font-semibold uppercase tracking-wide mb-2 text-muted">Videos</p>
        <div className="rounded-2xl overflow-hidden card">
          <VideoSlider videos={profile.videos || []} />
        </div>
      </div>
    </div>
  );
}
