"use client";
import React, { useRef } from "react";

/*
  NOTA: aquí guardamos la imagen como base64 directamente para que el
  flujo funcione sin configurar nada más. Antes de lanzar con clientes
  reales, reemplaza `onChange` para subir a Cloudinary/Supabase Storage
  y guardar solo la URL — guardar base64 en la base de datos no escala.
  Ver README, sección "Imágenes en producción".
*/
function resizeImage(file: File, maxW = 640, quality = 0.72): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxW / img.width);
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext("2d")!;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = reject;
      img.src = reader.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function ImagePicker({ value, onChange, label }: { value: string | null | undefined; onChange: (v: string | null) => void; label: string }) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <div>
      <div
        className="aspect-[4/3] rounded-xl overflow-hidden flex items-center justify-center cursor-pointer relative group bg-surface2 border border-dashed border-border"
        onClick={() => ref.current?.click()}
      >
        {value ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={value} alt="" className="w-full h-full object-cover" />
        ) : (
          <span className="text-xs text-muted">{label}</span>
        )}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 flex items-center justify-center transition-colors">
          <span className="text-white text-xs font-semibold opacity-0 group-hover:opacity-100">Cambiar</span>
        </div>
      </div>
      <input
        ref={ref}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          const dataUrl = await resizeImage(f);
          onChange(dataUrl);
        }}
      />
      {value && (
        <button className="text-xs mt-1 font-semibold text-danger" onClick={() => onChange(null)}>
          Quitar
        </button>
      )}
    </div>
  );
}
