"use client";
import React from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { signOut } from "next-auth/react";
import { UserCircle, LayoutGrid, CreditCard, Link2, Settings, ChevronRight, LogOut } from "lucide-react";
import { ROLES } from "@/lib/utils";
import { Button } from "./ui";

export function Sidebar({ username, role }: { username: string; role: string }) {
  const pathname = usePathname();
  const router = useRouter();

  const tabs = [
    { key: "perfil", label: "Mi perfil", icon: <UserCircle size={17} /> },
    { key: "botones", label: "Botones extra", icon: <LayoutGrid size={17} /> },
    { key: "plan", label: "Plan y pago", icon: <CreditCard size={17} /> },
    { key: "compartir", label: "Compartir", icon: <Link2 size={17} /> },
    ...(role === "ADMIN" || role === "MODERADOR" ? [{ key: "admin", label: "Administrador", icon: <Settings size={17} /> }] : []),
  ];

  return (
    <div className="w-full sm:w-56 flex-shrink-0">
      <div className="rounded-2xl border border-border p-3 mb-4 sm:mb-0 card">
        <div className="flex items-center gap-2.5 px-2 py-2 mb-2">
          <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 bg-primary text-white">
            {username?.slice(0, 1).toUpperCase()}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-bold truncate text-ink">{username}</p>
            <p className="text-xs text-muted">{ROLES[role]?.label || "Usuario"}</p>
          </div>
        </div>
        <nav className="flex sm:flex-col gap-1 overflow-x-auto sm:overflow-visible">
          {tabs.map((t) => {
            const isActive = pathname?.includes(`/dashboard/${t.key}`);
            return (
              <Link
                key={t.key}
                href={`/dashboard/${t.key}`}
                className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-semibold whitespace-nowrap transition-colors flex-shrink-0"
                style={{ background: isActive ? "#7C5CFC" : "transparent", color: isActive ? "#fff" : "#C7C9D6" }}
              >
                {t.icon}
                <span className="flex-1 text-left">{t.label}</span>
                {isActive && <ChevronRight size={14} className="hidden sm:block" />}
              </Link>
            );
          })}
        </nav>
        <div className="mt-2 px-1">
          <Button
            variant="outline"
            className="w-full"
            onClick={async () => {
              await signOut({ redirect: false });
              router.push("/");
              router.refresh();
            }}
          >
            <LogOut size={14} /> Salir
          </Button>
        </div>
      </div>
    </div>
  );
}
