# Ficha — Vitrinas digitales multiusuario

Proyecto real en **Next.js 14 (App Router) + Prisma + PostgreSQL + NextAuth**, listo para
desplegar en **Vercel** con base de datos en **Supabase**.

Incluye: registro/login/recuperar contraseña, perfiles con foto, descripción, 3 videos de
YouTube, imágenes tipo slider, redes sociales, botones extra configurables por plan,
perfiles verificados, planes de pago (Gratis / $10 / $15) con QR y aprobación manual de
comprobantes, y un panel de administración con métricas, buscador, historial de
aprobaciones y roles (Administrador / Moderador / Usuario).

---

## 1. Requisitos

- Node.js 18 o superior
- Una cuenta gratuita en [Supabase](https://supabase.com) (base de datos)
- Una cuenta gratuita en [Vercel](https://vercel.com) (para desplegar)
- Git y una cuenta de GitHub

---

## 2. Instalación local

```bash
# 1. Instala las dependencias
npm install

# 2. Copia el archivo de variables de entorno
cp .env.example .env

# 3. Completa .env con tus datos (ver sección 3 abajo)

# 4. Crea las tablas en la base de datos
npx prisma migrate dev --name init

# 5. Crea el usuario administrador y datos de ejemplo
npx prisma db seed

# 6. Levanta el proyecto en desarrollo
npm run dev
```

Abre `http://localhost:3000`. Inicia sesión con:
- **Admin:** usuario `admin`, contraseña `admin123`
- **Moderador:** usuario `moderador`, contraseña `mod123`
- **Usuarios de ejemplo:** `ropaurbana`, `tecnoshop`, `cafeteria_luna` — contraseña `demo123` para todos

**Cambia estas contraseñas antes de mostrarle el proyecto a un cliente real.**

---

## 3. Configurar Supabase (base de datos)

1. Crea un proyecto nuevo en Supabase.
2. Ve a **Project Settings → Database → Connection string**.
3. Copia la cadena en modo **Transaction** (puerto 6543) y pégala en `DATABASE_URL`.
4. Copia la cadena en modo **Session** (puerto 5432) y pégala en `DIRECT_URL`.
5. En `NEXTAUTH_SECRET`, genera un valor aleatorio, por ejemplo con:
   ```bash
   openssl rand -base64 32
   ```
6. `NEXTAUTH_URL` es `http://localhost:3000` en desarrollo y tu dominio real en producción.
7. `NEXT_PUBLIC_BRAND_NAME` es el nombre que aparece en el header — cámbialo por el
   nombre real de tu marca.

---

## 4. Subir a GitHub

```bash
git init
git add .
git commit -m "Primer commit: proyecto Ficha"
git branch -M main
git remote add origin https://github.com/tu-usuario/tu-repo.git
git push -u origin main
```

`.env` **no se sube** (está en `.gitignore`) — las variables de entorno se configuran
directamente en Vercel.

---

## 5. Desplegar en Vercel

1. Entra a Vercel → **Add New Project** → importa tu repositorio de GitHub.
2. En **Environment Variables**, agrega las mismas variables que tienes en tu `.env`
   (usando la URL de producción en `NEXTAUTH_URL`).
3. Despliega. Cada vez que hagas `git push` a `main`, Vercel actualiza el sitio solo.
4. Después del primer deploy, corre las migraciones y el seed contra la base de datos de
   producción (puedes hacerlo desde tu máquina apuntando el `.env` local a la base de
   Supabase de producción):
   ```bash
   npx prisma migrate deploy
   npx prisma db seed
   ```

---

## 6. Cosas que debes reemplazar antes de lanzar con clientes reales

Este proyecto es una base sólida y funcional, pero hay 3 atajos tomados para que
funcionara rápido que **debes cambiar antes de producción real**:

### a) Imágenes en base64 → Cloudinary o Supabase Storage
Ahora mismo las fotos se guardan como texto (base64) directo en la base de datos
(`components/ImagePicker.tsx`). Funciona, pero no escala bien con muchos usuarios.
Reemplázalo por una subida real a [Cloudinary](https://cloudinary.com) (tiene plan
gratuito) o a Supabase Storage, y guarda solo la URL en `photoUrl` / `images`.

### b) Recuperar contraseña → flujo con correo real
Ahora mismo (`app/api/auth/forgot-password/route.ts`) cambia la contraseña con solo
escribir el usuario, sin verificar que sea el dueño de la cuenta — es solo para que el
flujo se pudiera probar sin configurar un servicio de correo. Antes de producción,
cámbialo por un flujo de token de un solo uso enviado por email, usando
[Resend](https://resend.com) o similar.

### c) Pagos manuales → pasarela automática (opcional)
El sistema de QR + comprobante + aprobación manual que armamos funciona bien para
empezar. Si más adelante quieres automatizar los pagos, revisa **Wompi** o **PayU**
(Colombia) o **MercadoPago** (LatAm).

---

## 7. Estructura del proyecto

```
app/
  page.tsx                 → landing / directorio público
  [usuario]/page.tsx        → ficha pública de cada usuario (SEO)
  login/, registro/, olvide-password/
  dashboard/
    layout.tsx              → protege las rutas, muestra el sidebar
    perfil/, botones/, plan/, compartir/, admin/
  api/
    auth/                   → NextAuth, registro, recuperar contraseña
    profile/                → CRUD del perfil propio
    payments/                → enviar / aprobar / rechazar pagos
    admin/                   → usuarios, verificar, roles, config, historial
components/                 → UI reutilizable (botones, tarjetas, sliders, sidebar)
lib/                        → prisma, auth, utilidades compartidas
prisma/schema.prisma        → modelo de datos
prisma/seed.ts              → usuarios y datos de ejemplo
```

---

## 8. Próximos pasos sugeridos

- Cambiar la paleta de colores en `tailwind.config.ts` cuando tengas el diseño final
- Agregar categorías/rubros a los perfiles (Ropa, Comida, Servicios…) para filtros
- Agregar verificación de correo real al registrarse
- Agregar analítica simple (visitas por perfil, clics por botón)
