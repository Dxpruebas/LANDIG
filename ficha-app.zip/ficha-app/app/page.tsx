import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { VerifiedBadge, Badge, Button } from "@/components/ui";
import { PLANS } from "@/lib/utils";

export const dynamic = "force-dynamic";

const BRAND = process.env.NEXT_PUBLIC_BRAND_NAME || "Ficha";

export default async function HomePage() {
  const profiles = await prisma.profile.findMany({
    where: { published: true },
    include: { user: true },
    orderBy: { createdAt: "desc" },
    take: 60,
  });

  return (
    <div>
      <header className="max-w-5xl mx-auto px-6 py-6 flex items-center justify-between">
        <span className="text-lg font-bold font-display text-ink">{BRAND}</span>
        <div className="flex items-center gap-2">
          <Link href="/login">
            <Button variant="ghost">Iniciar sesión</Button>
          </Link>
          <Link href="/registro">
            <Button>Crear ficha</Button>
          </Link>
        </div>
      </header>

      <section className="max-w-3xl mx-auto px-6 pt-10 pb-10 text-center">
        <span className="inline-block text-xs font-semibold tracking-wide rounded-full px-3 py-1 mb-4 bg-surface2 text-muted font-mono">
          {BRAND.toUpperCase()} · VITRINAS DIGITALES
        </span>
        <h1 className="text-4xl sm:text-5xl font-bold font-display leading-tight text-ink">
          Tu negocio, tu ficha,
          <br />
          un solo link.
        </h1>
        <p className="mt-4 text-base max-w-lg mx-auto text-muted">
          Crea tu perfil con fotos, videos y redes sociales. Compártelo con un solo enlace. Gratis para empezar.
        </p>
        <div className="flex items-center justify-center gap-3 mt-7">
          <Link href="/registro">
            <Button>Crear mi ficha gratis</Button>
          </Link>
          <Link href="/login">
            <Button variant="outline">Ya tengo cuenta</Button>
          </Link>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-6 pb-20">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted">Explorar fichas publicadas</h2>
          <span className="text-xs text-muted">{profiles.length} perfiles</span>
        </div>
        {profiles.length === 0 ? (
          <div className="rounded-2xl p-10 text-center bg-surface2 text-muted">Todavía no hay fichas publicadas.</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
            {profiles.map((p) => (
              <Link key={p.id} href={`/${p.user.username}`} className="text-left group block">
                <div className="rounded-[22px] overflow-hidden card hover:border-primary transition-colors">
                  <div className="aspect-[4/3] w-full overflow-hidden bg-surface2 flex items-center justify-center">
                    {p.photoUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={p.photoUrl} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    ) : (
                      <span className="text-2xl font-bold text-border">{p.displayName.slice(0, 1).toUpperCase()}</span>
                    )}
                  </div>
                  <div className="p-4">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="font-bold text-sm truncate flex items-center gap-1 font-display text-ink">
                        {p.displayName}
                        {p.verified && <VerifiedBadge size={14} />}
                      </h3>
                      {p.planType !== "FREE" && p.planStatus === "active" && <Badge tone="good">{PLANS[p.planType].label}</Badge>}
                    </div>
                    <p className="text-xs mt-1 line-clamp-2 text-muted">{p.tagline || p.description || "Sin descripción todavía"}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
