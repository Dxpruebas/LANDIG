"use client";
import React, { useEffect, useState } from "react";
import { Check, UserCircle, ClipboardList, Video, Link2, MessageCircle, Instagram, Send } from "lucide-react";
import { Button, Field, TextInput, TextArea, SectionHeader, CheckToggleCard } from "@/components/ui";
import { ImagePicker } from "@/components/ImagePicker";

const SOCIAL_META: Record<string, { label: string; icon: React.ReactNode; placeholder: string }> = {
  whatsapp: { label: "WhatsApp", icon: <MessageCircle size={18} />, placeholder: "Número o link (ej: 573001234567)" },
  instagram: { label: "Instagram", icon: <Instagram size={18} />, placeholder: "@usuario o link" },
  telegram: { label: "Telegram", icon: <Send size={18} />, placeholder: "@usuario o link" },
};

export default function PerfilPage() {
  const [profile, setProfile] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch("/api/profile")
      .then((r) => r.json())
      .then(setProfile);
  }, []);

  async function save() {
    setSaving(true);
    setSaved(false);
    const res = await fetch("/api/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(profile),
    });
    setSaving(false);
    if (res.ok) {
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    }
  }

  if (!profile) return <p className="text-sm text-muted">Cargando…</p>;

  const images = profile.images?.length ? profile.images : [null, null, null];
  const videos = profile.videos?.length ? profile.videos : ["", "", ""];
  const social = profile.social || {};

  return (
    <div className="max-w-2xl">
      <SectionHeader icon={<UserCircle size={16} />} title="Presentación" hint="Foto e imágenes que verán tus visitantes" />
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-2">
        <div className="col-span-2 sm:col-span-1">
          <p className="text-xs font-semibold uppercase tracking-wide mb-1.5 text-muted">Foto de presentación</p>
          <ImagePicker value={profile.photoUrl} onChange={(v) => setProfile({ ...profile, photoUrl: v })} label="Subir foto" />
        </div>
        {[0, 1, 2].map((idx) => (
          <div key={idx}>
            <p className="text-xs font-semibold uppercase tracking-wide mb-1.5 text-muted">Imagen {idx + 1}</p>
            <ImagePicker
              value={images[idx]}
              onChange={(v) => {
                const imgs = [...images];
                imgs[idx] = v;
                setProfile({ ...profile, images: imgs });
              }}
              label="Subir"
            />
          </div>
        ))}
      </div>

      <SectionHeader icon={<ClipboardList size={16} />} title="Información" hint="Quién eres y qué haces" />
      <Field label="Nombre / negocio">
        <TextInput value={profile.displayName} onChange={(e) => setProfile({ ...profile, displayName: e.target.value })} />
      </Field>
      <Field label="Frase corta" hint="Aparece debajo del nombre en tu ficha">
        <TextInput value={profile.tagline} onChange={(e) => setProfile({ ...profile, tagline: e.target.value })} placeholder="Ej: Ropa urbana hecha en Colombia" />
      </Field>
      <Field label="Descripción" hint="Cuenta quién eres y qué haces">
        <TextArea rows={4} value={profile.description} onChange={(e) => setProfile({ ...profile, description: e.target.value })} />
      </Field>

      <SectionHeader icon={<Video size={16} />} title="Videos de YouTube" hint="Hasta 3, se reproducen dentro de tu ficha" />
      {[0, 1, 2].map((idx) => (
        <Field key={idx} label={`Video ${idx + 1}`}>
          <TextInput
            value={videos[idx] || ""}
            onChange={(e) => {
              const vids = [...videos];
              vids[idx] = e.target.value;
              setProfile({ ...profile, videos: vids });
            }}
            placeholder="https://www.youtube.com/watch?v=..."
          />
        </Field>
      ))}

      <SectionHeader icon={<Link2 size={16} />} title="Redes sociales" hint="Marca la casilla para mostrar el botón en tu ficha pública" />
      <div className="flex flex-col gap-3">
        {Object.entries(SOCIAL_META).map(([key, meta]) => (
          <CheckToggleCard
            key={key}
            icon={meta.icon}
            title={meta.label}
            subtitle={social[key]?.visible ? "Visible en tu ficha" : "Oculto"}
            checked={!!social[key]?.visible}
            onChange={(v) =>
              setProfile({ ...profile, social: { ...social, [key]: { ...(social[key] || {}), visible: v } } })
            }
          >
            <TextInput
              value={social[key]?.url || ""}
              onChange={(e) => setProfile({ ...profile, social: { ...social, [key]: { ...(social[key] || {}), url: e.target.value } } })}
              placeholder={meta.placeholder}
            />
          </CheckToggleCard>
        ))}
      </div>

      <div className="mt-8 sticky bottom-4">
        <Button onClick={save} disabled={saving}>
          {saving ? "Guardando…" : saved ? (<><Check size={16} /> Guardado</>) : (<><Check size={16} /> Guardar cambios</>)}
        </Button>
      </div>
    </div>
  );
}
