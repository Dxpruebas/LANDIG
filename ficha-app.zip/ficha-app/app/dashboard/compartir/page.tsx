"use client";
import React, { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { Button } from "@/components/ui";

export default function CompartirPage() {
  const { data: session } = useSession();
  const [origin, setOrigin] = useState("");

  useEffect(() => {
    setOrigin(window.location.origin);
  }, []);

  const username = session?.user?.username || "";
  const shareUrl = username ? `${origin}/${username}` : "";
  const qrUrl = shareUrl ? `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(shareUrl)}` : "";

  return (
    <div className="max-w-md">
      <p className="text-sm mb-4 text-muted">Este es el enlace público de tu ficha. Compártelo en tus redes o imprímelo como QR.</p>
      <div className="rounded-2xl p-5 border border-border flex flex-col items-center gap-4">
        {qrUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={qrUrl} alt="QR de tu perfil" width={160} height={160} />
        ) : (
          <p className="text-sm text-muted">Cargando…</p>
        )}
        <p className="text-xs break-all text-center font-mono text-ink">{shareUrl}</p>
        <Button variant="outline" onClick={() => shareUrl && navigator.clipboard?.writeText(shareUrl)}>
          Copiar enlace
        </Button>
      </div>
    </div>
  );
}
