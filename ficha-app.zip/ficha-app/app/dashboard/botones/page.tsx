"use client";
import React, { useEffect, useState } from "react";
import { Check, LayoutGrid, Link2, ShieldCheck } from "lucide-react";
import { Button, TextInput, SectionHeader, CheckToggleCard } from "@/components/ui";
import { PLANS } from "@/lib/utils";

export default function BotonesPage() {
  const [profile, setProfile] = useState<any>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/profile")
      .then((r) => r.json())
      .then(setProfile);
  }, []);

  async function save() {
    setSaving(true);
    await fetch("/api/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ extraButtons: profile.extraButtons }),
    });
    setSaving(false);
  }

  if (!profile) return <p className="text-sm text-muted">Cargando…</p>;

  const allowed = PLANS[profile.planType]?.extraButtons ?? 0;
  const planActive = profile.planStatus === "active";
  const buttons = profile.extraButtons?.length ? profile.extraButtons : [
    { id: "1", label: "", url: "", visible: false },
    { id: "2", label: "", url: "", visible: false },
    { id: "3", label: "", url: "", visible: false },
  ];

  return (
    <div className="max-w-2xl">
      <SectionHeader icon={<LayoutGrid size={16} />} title="Botones extra" hint="Enlaces personalizados que aparecen en tu ficha pública" />
      <div className="rounded-xl p-4 mb-5 flex items-center gap-2 bg-surface2">
        <ShieldCheck size={16} className="text-success" />
        <p className="text-sm text-ink">
          Tu plan actual (<b>{PLANS[profile.planType].label}</b>) permite <b>{allowed} botón{allowed === 1 ? "" : "es"} extra</b>
          {!planActive && " — plan inactivo"}.
        </p>
      </div>
      <div className="flex flex-col gap-3">
        {buttons.map((b: any, idx: number) => {
          const unlocked = planActive && idx < allowed;
          return (
            <CheckToggleCard
              key={b.id}
              icon={<Link2 size={18} />}
              title={`Botón extra ${idx + 1}`}
              subtitle={unlocked ? (b.visible ? "Visible en tu ficha" : "Oculto") : "Bloqueado — mejora tu plan para usarlo"}
              checked={b.visible}
              locked={!unlocked}
              onChange={(v) => {
                const btns = [...buttons];
                btns[idx] = { ...b, visible: v };
                setProfile({ ...profile, extraButtons: btns });
              }}
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <TextInput
                  placeholder="Texto del botón (ej: Ver catálogo)"
                  value={b.label}
                  onChange={(e) => {
                    const btns = [...buttons];
                    btns[idx] = { ...b, label: e.target.value };
                    setProfile({ ...profile, extraButtons: btns });
                  }}
                />
                <TextInput
                  placeholder="Enlace (https://...)"
                  value={b.url}
                  onChange={(e) => {
                    const btns = [...buttons];
                    btns[idx] = { ...b, url: e.target.value };
                    setProfile({ ...profile, extraButtons: btns });
                  }}
                />
              </div>
            </CheckToggleCard>
          );
        })}
      </div>
      <Button onClick={save} disabled={saving} className="mt-5">
        {saving ? "Guardando…" : (<><Check size={16} /> Guardar cambios</>)}
      </Button>
    </div>
  );
}
