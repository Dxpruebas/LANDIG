"use client";
import React, { useEffect, useState } from "react";
import { Check } from "lucide-react";
import { Button, Field, TextArea, Badge } from "@/components/ui";
import { PLANS, daysLeft } from "@/lib/utils";

export default function PlanPage() {
  const [profile, setProfile] = useState<any>(null);
  const [config, setConfig] = useState<any>(null);
  const [selected, setSelected] = useState("BASICO");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch("/api/profile").then((r) => r.json()).then((p) => {
      setProfile(p);
      setSelected(p.planType === "FREE" ? "BASICO" : p.planType);
    });
    fetch("/api/admin/config").then((r) => r.json()).then(setConfig);
  }, []);

  if (!profile) return <p className="text-sm text-muted">Cargando…</p>;

  const planActive = profile.planStatus === "active";
  const qrData = config?.paymentInfo || "Pago manual — contacta al administrador";
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(qrData)}`;

  async function submitPayment() {
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/payments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ plan: selected, note }),
    });
    setBusy(false);
    if (res.ok) setMessage("¡Comprobante enviado! Espera la aprobación del administrador.");
  }

  return (
    <div className="max-w-2xl">
      <div className="rounded-xl p-4 mb-6 bg-surface2">
        <div className="flex items-center gap-2 mb-1">
          <Badge tone={planActive ? "good" : "bad"}>{planActive ? "Activo" : "Inactivo"}</Badge>
          <span className="text-sm font-semibold text-ink">Plan {PLANS[profile.planType].label}</span>
        </div>
        {profile.planEnd && (
          <p className="text-xs font-mono text-muted">
            Inicio: {new Date(profile.planStart).toLocaleDateString()} · Corte: {new Date(profile.planEnd).toLocaleDateString()}{" "}
            {planActive && `(${daysLeft(profile.planEnd)} días restantes)`}
          </p>
        )}
      </div>

      <p className="text-xs font-semibold uppercase tracking-wide mb-2 text-muted">Elige un plan</p>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
        {Object.values(PLANS).map((p) => (
          <button
            key={p.key}
            onClick={() => p.key !== "FREE" && setSelected(p.key)}
            className="relative text-left rounded-2xl p-4 border-2 transition-all"
            style={{
              borderColor: selected === p.key ? "#7C5CFC" : "#262837",
              background: selected === p.key ? "rgba(124,92,252,0.08)" : "#14151F",
              opacity: p.key === "FREE" ? 0.6 : 1,
            }}
          >
            {selected === p.key && (
              <span className="absolute top-3 right-3 w-5 h-5 rounded-full flex items-center justify-center bg-primary">
                <Check size={12} color="#fff" strokeWidth={3} />
              </span>
            )}
            <p className="font-bold text-sm font-display text-ink">{p.label}</p>
            <p className="text-xl font-bold mt-1 text-ink">{p.price === 0 ? "Gratis" : `$${p.price}/mes`}</p>
            <p className="text-xs mt-1 text-muted">{p.extraButtons} botón{p.extraButtons === 1 ? "" : "es"} extra</p>
          </button>
        ))}
      </div>

      {selected !== "FREE" && (
        <div className="rounded-2xl p-5 border border-border">
          <p className="text-xs font-semibold uppercase tracking-wide mb-3 text-muted">Paga y envía tu comprobante</p>
          <div className="flex flex-col sm:flex-row gap-5">
            <div className="flex flex-col items-center gap-2">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={qrUrl} alt="QR de pago" width={140} height={140} className="rounded-lg border border-border" />
              <p className="text-[11px] text-center max-w-[140px] text-muted">{qrData}</p>
            </div>
            <div className="flex-1">
              <Field label="Referencia / nota del comprobante" hint="Describe tu pago (número de transacción, banco, etc.)">
                <TextArea rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Ej: Transferencia Nequi #123456" />
              </Field>
              <Button onClick={submitPayment} disabled={busy || !note.trim()}>
                {busy ? "Enviando…" : "Enviar comprobante"}
              </Button>
              {message && <p className="text-sm mt-2 text-success">{message}</p>}
              <p className="text-xs mt-3 text-muted">Un administrador revisará tu comprobante y activará tu plan por 30 días.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
