import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { Sidebar } from "@/components/Sidebar";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  return (
    <div className="max-w-5xl mx-auto px-6 pt-8 pb-16 flex flex-col sm:flex-row gap-6">
      <Sidebar username={session.user.username} role={session.user.role} />
      <div className="flex-1 min-w-0 rounded-2xl border border-border p-5 sm:p-7 card">{children}</div>
    </div>
  );
}
