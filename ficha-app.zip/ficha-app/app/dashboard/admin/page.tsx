"use client";
import React, { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { Search, Users, DollarSign, CreditCard, Clock, BadgeCheck, LayoutGrid, History, Settings } from "lucide-react";
import { Button, TextInput, TextArea, Field, Badge, VerifiedBadge } from "@/components/ui";
import { PLANS, ROLES } from "@/lib/utils";

function MetricCard({ label, value, tone = "neutral", icon }: { label: string; value: any; tone?: "neutral" | "good" | "warn"; icon?: React.ReactNode }) {
  const tones: Record<string, string> = { neutral: "text-ink", good: "text-success", warn: "text-warning" };
  return (
    <div className="rounded-xl p-4 border border-border">
      <div className="flex items-center gap-1.5 mb-0.5 text-muted">
        {icon}
        <p className="text-xs font-semibold uppercase tracking-wide">{label}</p>
      </div>
      <p className={`text-2xl font-bold mt-1 font-display ${tones[tone]}`}>{value}</p>
    </div>
  );
}

export default function AdminPage() {
  const { data: session } = useSession();
  const role = session?.user?.role || "USER";
  const perms = ROLES[role] || ROLES.USER;

  const [sub, setSub] = useState("resumen");
  const [users, setUsers] = useState<any[]>([]);
  const [pending, setPending] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [config, setConfig] = useState<any>(null);
  const [paymentInfo, setPaymentInfo] = useState("");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [editingUser, setEditingUser] = useState<string | null>(null);

  async function loadAll() {
    const [u, p, h, c] = await Promise.all([
      fetch("/api/admin/users").then((r) => r.json()),
      fetch("/api/payments").then((r) => r.json()),
      fetch("/api/admin/history").then((r) => r.json()),
      fetch("/api/admin/config").then((r) => r.json()),
    ]);
    setUsers(Array.isArray(u) ? u : []);
    setPending(Array.isArray(p) ? p : []);
    setHistory(Array.isArray(h) ? h : []);
    setConfig(c);
    setPaymentInfo(c?.paymentInfo || "");
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const totalUsers = users.length;
  const payingUsers = users.filter((u) => u.profile?.planType !== "FREE" && u.profile?.planStatus === "active").length;
  const monthlyIncome = users
    .filter((u) => u.profile?.planType !== "FREE" && u.profile?.planStatus === "active")
    .reduce((sum, u) => sum + (PLANS[u.profile.planType]?.price || 0), 0);
  const verifiedCount = users.filter((u) => u.profile?.verified).length;
  const expiredCount = users.filter((u) => u.profile?.planStatus === "expired").length;

  const filtered = users.filter((u) => {
    const p = u.profile;
    if (!p) return false;
    const matchesQuery = !query || u.username.toLowerCase().includes(query.toLowerCase()) || p.displayName.toLowerCase().includes(query.toLowerCase());
    let matchesStatus = true;
    if (statusFilter === "activos") matchesStatus = p.planStatus === "active" && p.planType !== "FREE";
    if (statusFilter === "vencidos") matchesStatus = p.planStatus === "expired";
    if (statusFilter === "gratis") matchesStatus = p.planType === "FREE";
    return matchesQuery && matchesStatus;
  });

  async function approve(id: string) {
    await fetch(`/api/payments/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "approve" }) });
    loadAll();
  }
  async function reject(id: string) {
    await fetch(`/api/payments/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "reject" }) });
    loadAll();
  }
  async function toggleVerified(userId: string, verified: boolean) {
    await fetch("/api/admin/verify", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, verified }) });
    loadAll();
  }
  async function saveUserField(userId: string, fields: Record<string, string>) {
    await fetch("/api/admin/users", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, ...fields }) });
    loadAll();
  }
  async function changeRole(userId: string, role: string) {
    await fetch("/api/admin/role", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, role }) });
    loadAll();
  }
  async function saveConfig() {
    await fetch("/api/admin/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ paymentInfo }) });
    loadAll();
  }

  const subTabs = [
    { key: "resumen", label: "Resumen", icon: <LayoutGrid size={14} /> },
    { key: "usuarios", label: "Usuarios", icon: <Users size={14} /> },
    { key: "pagos", label: "Pagos pendientes", icon: <DollarSign size={14} /> },
    { key: "historial", label: "Historial", icon: <History size={14} /> },
    ...(perms.canManageUsers ? [{ key: "config", label: "Configuración", icon: <Settings size={14} /> }] : []),
  ];

  return (
    <div className="max-w-4xl">
      <div className="flex gap-2 flex-wrap mb-6">
        {subTabs.map((it) => (
          <button
            key={it.key}
            onClick={() => setSub(it.key)}
            className="flex items-center gap-1.5 text-xs font-semibold rounded-full px-3.5 py-1.5 transition-colors"
            style={{ background: sub === it.key ? "#F4F5F8" : "#1B1D29", color: sub === it.key ? "#0A0B10" : "#8B8FA3" }}
          >
            {it.icon}
            {it.label}
          </button>
        ))}
      </div>

      {sub === "resumen" && (
        <div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
            <MetricCard label="Usuarios totales" value={totalUsers} icon={<Users size={13} />} />
            <MetricCard label="Usuarios pagando" value={payingUsers} tone="good" icon={<DollarSign size={13} />} />
            <MetricCard label="Ingresos del mes" value={`$${monthlyIncome}`} tone="good" icon={<CreditCard size={13} />} />
            <MetricCard label="Pendientes de aprobar" value={pending.length} tone="warn" icon={<Clock size={13} />} />
            <MetricCard label="Perfiles verificados" value={verifiedCount} icon={<BadgeCheck size={13} />} />
            <MetricCard label="Planes vencidos" value={expiredCount} icon={<Clock size={13} />} />
          </div>
          <p className="text-xs text-muted">
            Conectado como <b className="text-ink">{ROLES[role]?.label}</b>.{" "}
            {!perms.canManageUsers && "Tu rol puede aprobar pagos y verificar perfiles, pero no editar usuarios ni la configuración general."}
          </p>
        </div>
      )}

      {sub === "usuarios" && (
        <div>
          <div className="flex flex-col sm:flex-row gap-2 mb-4">
            <div className="relative flex-1">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
              <TextInput className="pl-9" placeholder="Buscar por usuario o nombre…" value={query} onChange={(e) => setQuery(e.target.value)} />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="input-base w-full sm:w-48"
            >
              <option value="todos">Todos</option>
              <option value="activos">Con plan activo</option>
              <option value="vencidos">Vencidos</option>
              <option value="gratis">Plan gratis</option>
            </select>
          </div>
          <div className="flex flex-col gap-2">
            {filtered.length === 0 && <div className="rounded-xl p-6 text-center text-sm bg-surface2 text-muted">Sin resultados.</div>}
            {filtered.map((u) => (
              <div key={u.id} className="rounded-xl p-3.5 border border-border flex flex-wrap items-center gap-3 justify-between">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold bg-surface2 text-ink">
                    {u.profile.displayName.slice(0, 1).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold truncate flex items-center gap-1 text-ink">
                      {u.profile.displayName} {u.profile.verified && <VerifiedBadge size={13} />}
                    </p>
                    <p className="text-xs truncate font-mono text-muted">@{u.username}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge tone={u.profile.planStatus === "active" ? "good" : u.profile.planStatus === "expired" ? "bad" : "neutral"}>
                    {PLANS[u.profile.planType].label} · {u.profile.planStatus === "active" ? "activo" : u.profile.planStatus === "expired" ? "vencido" : "sin iniciar"}
                  </Badge>
                  {perms.canVerify && (
                    <Button variant="outline" onClick={() => toggleVerified(u.id, !u.profile.verified)}>
                      {u.profile.verified ? "Quitar verificación" : "Verificar"}
                    </Button>
                  )}
                  {perms.canManageUsers && (
                    <Button variant="ghost" onClick={() => setEditingUser(editingUser === u.id ? null : u.id)}>
                      {editingUser === u.id ? "Cerrar" : "Editar"}
                    </Button>
                  )}
                </div>
                {editingUser === u.id && perms.canManageUsers && (
                  <div className="w-full mt-2 rounded-lg p-3 bg-surface2">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-2">
                      <Field label="Nombre / negocio">
                        <TextInput defaultValue={u.profile.displayName} onBlur={(e) => saveUserField(u.id, { displayName: e.target.value })} />
                      </Field>
                      <Field label="Rol de la cuenta">
                        <select
                          defaultValue={u.role}
                          onChange={(e) => changeRole(u.id, e.target.value)}
                          className="input-base"
                        >
                          <option value="USER">Usuario</option>
                          <option value="MODERADOR">Moderador</option>
                          <option value="ADMIN">Administrador</option>
                        </select>
                      </Field>
                    </div>
                    <Field label="Descripción">
                      <TextArea rows={2} defaultValue={u.profile.description} onBlur={(e) => saveUserField(u.id, { description: e.target.value })} />
                    </Field>
                    <p className="text-xs text-muted">Los cambios se guardan al salir del campo.</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {sub === "pagos" && (
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide mb-2 text-muted">Solicitudes de pago pendientes ({pending.length})</p>
          {pending.length === 0 ? (
            <div className="rounded-xl p-6 text-center text-sm bg-surface2 text-muted">No hay solicitudes pendientes.</div>
          ) : (
            <div className="flex flex-col gap-3">
              {pending.map((p) => (
                <div key={p.id} className="rounded-xl p-4 border border-border">
                  <div className="flex items-center justify-between">
                    <p className="font-bold text-sm text-ink">
                      {p.user.username} <span className="font-normal text-xs text-muted">→ plan {PLANS[p.plan].label}</span>
                    </p>
                    <Badge tone="warn">Pendiente</Badge>
                  </div>
                  <p className="text-sm mt-2 text-ink">{p.note}</p>
                  <p className="text-xs mt-1 text-muted">Enviado: {new Date(p.submittedAt).toLocaleString()}</p>
                  <div className="flex gap-2 mt-3">
                    <Button onClick={() => approve(p.id)}>Aprobar y activar 30 días</Button>
                    <Button variant="outline" onClick={() => reject(p.id)}>Rechazar</Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {sub === "historial" && (
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide mb-2 text-muted">Historial de aprobaciones y rechazos</p>
          {history.length === 0 ? (
            <div className="rounded-xl p-6 text-center text-sm bg-surface2 text-muted">Todavía no hay movimientos registrados.</div>
          ) : (
            <div className="flex flex-col gap-2">
              {history.map((h) => (
                <div key={h.id} className="rounded-lg p-3 border border-border flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm text-ink">
                      <b>{h.actor}</b> {h.action === "approve" ? "aprobó" : "rechazó"} el pago de <b>@{h.targetUsername}</b>
                      {h.plan && ` (plan ${PLANS[h.plan]?.label || h.plan})`}
                    </p>
                    <p className="text-xs font-mono text-muted">{new Date(h.timestamp).toLocaleString()}</p>
                  </div>
                  <Badge tone={h.action === "approve" ? "good" : "bad"}>{h.action === "approve" ? "Aprobado" : "Rechazado"}</Badge>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {sub === "config" && perms.canManageUsers && (
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide mb-2 text-muted">Datos del QR de pago (visible para todos los usuarios)</p>
          <div className="flex gap-2">
            <TextInput value={paymentInfo} onChange={(e) => setPaymentInfo(e.target.value)} placeholder="Ej: Nequi 3001234567 - Mi Empresa SAS" />
            <Button onClick={saveConfig}>Guardar</Button>
          </div>
        </div>
      )}
    </div>
  );
}
