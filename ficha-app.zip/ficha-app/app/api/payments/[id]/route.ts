import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ROLES, addDays } from "@/lib/utils";

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session || !ROLES[session.user.role]?.canApprovePayments) {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }
  const { action } = await req.json(); // "approve" | "reject"
  const payment = await prisma.payment.findUnique({ where: { id: params.id }, include: { user: true } });
  if (!payment) return NextResponse.json({ error: "No encontrado" }, { status: 404 });

  if (action === "approve") {
    const start = new Date();
    await prisma.profile.update({
      where: { userId: payment.userId },
      data: { planType: payment.plan, planStatus: "active", planStart: start, planEnd: addDays(start, 30) },
    });
  }

  await prisma.payment.update({
    where: { id: params.id },
    data: { status: action === "approve" ? "approved" : "rejected", reviewedBy: session.user.username, reviewedAt: new Date() },
  });

  await prisma.historyLog.create({
    data: { actor: session.user.username, action, targetUsername: payment.user.username, plan: payment.plan },
  });

  return NextResponse.json({ ok: true });
}
