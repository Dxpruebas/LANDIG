import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ROLES } from "@/lib/utils";

// El usuario envía su comprobante de pago (queda pendiente de aprobación)
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const { plan, note } = await req.json();
  if (!plan || !note) return NextResponse.json({ error: "Faltan datos." }, { status: 400 });

  const payment = await prisma.payment.create({
    data: { userId: session.user.id, plan, note, status: "pending" },
  });
  return NextResponse.json(payment);
}

// Admin/Moderador: ver todas las solicitudes pendientes
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || !ROLES[session.user.role]?.canApprovePayments) {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }
  const pending = await prisma.payment.findMany({
    where: { status: "pending" },
    include: { user: { include: { profile: true } } },
    orderBy: { submittedAt: "asc" },
  });
  return NextResponse.json(pending);
}
