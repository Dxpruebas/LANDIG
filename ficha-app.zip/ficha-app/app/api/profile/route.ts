import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const profile = await prisma.profile.findUnique({ where: { userId: session.user.id } });
  return NextResponse.json(profile);
}

export async function PATCH(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const body = await req.json();

  // Solo permitimos que el usuario edite estos campos de su propio perfil
  const allowed = ["displayName", "tagline", "description", "photoUrl", "images", "videos", "social", "extraButtons"];
  const data: Record<string, unknown> = {};
  for (const key of allowed) if (key in body) data[key] = body[key];

  const updated = await prisma.profile.update({ where: { userId: session.user.id }, data });
  return NextResponse.json(updated);
}
