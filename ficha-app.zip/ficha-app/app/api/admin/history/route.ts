import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ROLES } from "@/lib/utils";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || !ROLES[session.user.role]?.canApprovePayments) {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }
  const log = await prisma.historyLog.findMany({ orderBy: { timestamp: "desc" }, take: 100 });
  return NextResponse.json(log);
}
