import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ROLES } from "@/lib/utils";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !ROLES[session.user.role]?.canVerify) {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }
  const { userId, verified } = await req.json();
  const updated = await prisma.profile.update({ where: { userId }, data: { verified } });
  return NextResponse.json(updated);
}
