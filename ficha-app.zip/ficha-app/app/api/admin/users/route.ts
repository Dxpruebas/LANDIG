import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ROLES } from "@/lib/utils";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || !ROLES[session.user.role]?.canApprovePayments) {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }
  const users = await prisma.user.findMany({
    include: { profile: true },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(users);
}

// Solo ADMIN puede editar el perfil de otro usuario (soporte al cliente)
export async function PATCH(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session || session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }
  const { userId, ...fields } = await req.json();
  const allowed = ["displayName", "tagline", "description"];
  const data: Record<string, unknown> = {};
  for (const key of allowed) if (key in fields) data[key] = fields[key];

  const updated = await prisma.profile.update({ where: { userId }, data });
  return NextResponse.json(updated);
}
