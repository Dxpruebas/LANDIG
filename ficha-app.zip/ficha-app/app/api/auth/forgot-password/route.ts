import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";

/*
  NOTA IMPORTANTE: esta versión cambia la contraseña directamente con solo
  el nombre de usuario, para que el flujo funcione sin backend de correo.
  Antes de usarlo con clientes reales, esto DEBE reemplazarse por un flujo
  con token de un solo uso enviado por email (ver README, sección
  "Recuperación de contraseña real").
*/

export async function POST(req: Request) {
  const { username, newPassword } = await req.json();
  if (!username || !newPassword || newPassword.length < 4) {
    return NextResponse.json({ error: "Datos inválidos." }, { status: 400 });
  }
  const user = await prisma.user.findUnique({ where: { username } });
  if (!user) {
    return NextResponse.json({ error: "Ese usuario no existe." }, { status: 404 });
  }
  const passwordHash = await bcrypt.hash(newPassword, 10);
  await prisma.user.update({ where: { username }, data: { passwordHash } });
  return NextResponse.json({ ok: true });
}
