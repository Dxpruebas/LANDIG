import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const { username, email, password } = await req.json();

  if (!username || username.length < 3) {
    return NextResponse.json({ error: "El usuario debe tener al menos 3 caracteres." }, { status: 400 });
  }
  if (!password || password.length < 4) {
    return NextResponse.json({ error: "La contraseña es muy corta." }, { status: 400 });
  }

  const existingUsername = await prisma.user.findUnique({ where: { username } });
  if (existingUsername) {
    return NextResponse.json({ error: "Ese usuario ya existe. Prueba con otro." }, { status: 409 });
  }
  if (email) {
    const existingEmail = await prisma.user.findUnique({ where: { email } });
    if (existingEmail) {
      return NextResponse.json({ error: "Ese correo ya está registrado." }, { status: 409 });
    }
  }

  const passwordHash = await bcrypt.hash(password, 10);

  const user = await prisma.user.create({
    data: {
      username,
      email: email || `${username}@sin-correo.local`,
      passwordHash,
      role: "USER",
      profile: {
        create: {
          displayName: username,
          social: {
            whatsapp: { url: "", visible: false },
            instagram: { url: "", visible: false },
            telegram: { url: "", visible: false },
          },
          extraButtons: [
            { id: "1", label: "", url: "", visible: false },
            { id: "2", label: "", url: "", visible: false },
            { id: "3", label: "", url: "", visible: false },
          ],
        },
      },
    },
  });

  return NextResponse.json({ ok: true, username: user.username });
}
