"use client";
import React, { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Button, Field, TextInput } from "@/components/ui";

export default function RegistroPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (password !== confirm) {
      setError("Las contraseñas no coinciden.");
      return;
    }
    setBusy(true);
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: username.trim(), email: email.trim(), password }),
    });
    const data = await res.json();
    if (!res.ok) {
      setBusy(false);
      setError(data.error || "No se pudo crear la cuenta.");
      return;
    }
    // login automático tras registrarse
    await signIn("credentials", { username, password, redirect: false });
    setBusy(false);
    router.push("/dashboard/perfil");
    router.refresh();
  }

  return (
    <div className="max-w-sm mx-auto px-6 py-16">
      <h1 className="text-2xl font-bold font-display text-ink">Crear tu ficha</h1>
      <p className="text-sm mt-1.5 text-muted">Gratis. Puedes mejorar tu plan cuando quieras.</p>

      <form onSubmit={handleSubmit} className="mt-6">
        <Field label="Usuario" hint="Será parte de tu enlace público">
          <TextInput value={username} onChange={(e) => setUsername(e.target.value)} placeholder="mi_negocio" autoFocus />
        </Field>
        <Field label="Correo">
          <TextInput type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="correo@ejemplo.com" />
        </Field>
        <Field label="Contraseña">
          <TextInput type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
        </Field>
        <Field label="Confirmar contraseña">
          <TextInput type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="••••••••" />
        </Field>
        {error && <p className="text-sm mb-3 text-danger">{error}</p>}
        <Button type="submit" className="w-full" disabled={busy}>
          {busy ? "Creando…" : "Crear cuenta gratis"}
        </Button>
      </form>

      <div className="mt-5 text-sm">
        <Link href="/login" className="font-semibold text-ink">
          ¿Ya tienes cuenta? Inicia sesión →
        </Link>
      </div>
    </div>
  );
}
