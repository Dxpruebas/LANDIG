import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { PublicProfileView } from "@/components/PublicProfileView";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: { usuario: string } }) {
  const profile = await prisma.profile.findFirst({ where: { user: { username: params.usuario } } });
  if (!profile) return { title: "Perfil no encontrado" };
  return {
    title: profile.displayName,
    description: profile.tagline || profile.description || undefined,
  };
}

export default async function PublicProfilePage({ params }: { params: { usuario: string } }) {
  const profile = await prisma.profile.findFirst({
    where: { user: { username: params.usuario } },
    include: { user: true },
  });
  if (!profile || !profile.published) return notFound();

  return (
    <div>
      <div className="max-w-md mx-auto px-4 pt-6">
        <Link href="/" className="text-xs font-semibold text-muted hover:text-ink">
          ← Explorar
        </Link>
      </div>
      <PublicProfileView profile={profile} />
    </div>
  );
}
