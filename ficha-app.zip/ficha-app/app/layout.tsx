import type { Metadata } from "next";
import { Space_Grotesk, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/Providers";

const display = Space_Grotesk({ subsets: ["latin"], variable: "--font-display", weight: ["500", "600", "700"] });
const body = Inter({ subsets: ["latin"], variable: "--font-body" });
const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono" });

const BRAND = process.env.NEXT_PUBLIC_BRAND_NAME || "Ficha";

export const metadata: Metadata = {
  title: `${BRAND} — Vitrinas digitales`,
  description: "Crea tu perfil, comparte tu link, haz crecer tu negocio.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" className={`${display.variable} ${body.variable} ${mono.variable}`}>
      <body className="bg-bg text-ink min-h-screen antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
