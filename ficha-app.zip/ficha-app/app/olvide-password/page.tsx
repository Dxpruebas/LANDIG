"use client";
import React, { useState } from "react";
import Link from "next/link";
import { Button, Field, TextInput } from "@/components/ui";

export default function OlvidePasswordPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setMessage("");
    setBusy(true);
    const res = await fetch("/api/auth/forgot-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: username.trim(), newPassword: password }),
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) {
      setError(data.error || "No se pudo cambiar la contraseña.");
      return;
    }
    setMessage("Contraseña actualizada. Ya puedes iniciar sesión.");
  }

  return (
    <div className="max-w-sm mx-auto px-6 py-16">
      <h1 className="text-2xl font-bold font-display text-ink">Cambiar contraseña</h1>
      <p className="text-sm mt-1.5 text-muted">
        Escribe tu usuario y la nueva contraseña. (Ver README para reemplazar esto por un flujo con correo real.)
      </p>

      <form onSubmit={handleSubmit} className="mt-6">
        <Field label="Usuario">
          <TextInput value={username} onChange={(e) => setUsername(e.target.value)} placeholder="tu_usuario" autoFocus />
        </Field>
        <Field label="Nueva contraseña">
          <TextInput type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
        </Field>
        {error && <p className="text-sm mb-3 text-danger">{error}</p>}
        {message && <p className="text-sm mb-3 text-success">{message}</p>}
        <Button type="submit" className="w-full" disabled={busy}>
          {busy ? "Guardando…" : "Cambiar contraseña"}
        </Button>
      </form>

      <div className="mt-5 text-sm">
        <Link href="/login" className="font-semibold text-ink">
          ← Volver a iniciar sesión
        </Link>
      </div>
    </div>
  );
}
