"use client";
import React, { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Button, Field, TextInput } from "@/components/ui";

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setBusy(true);
    const res = await signIn("credentials", { username, password, redirect: false });
    setBusy(false);
    if (res?.error) {
      setError("Usuario o contraseña incorrectos.");
      return;
    }
    router.push("/dashboard/perfil");
    router.refresh();
  }

  return (
    <div className="max-w-sm mx-auto px-6 py-16">
      <h1 className="text-2xl font-bold font-display text-ink">Iniciar sesión</h1>
      <p className="text-sm mt-1.5 text-muted">Entra para editar tu ficha.</p>

      <form onSubmit={handleSubmit} className="mt-6">
        <Field label="Usuario">
          <TextInput value={username} onChange={(e) => setUsername(e.target.value)} placeholder="tu_usuario" autoFocus />
        </Field>
        <Field label="Contraseña">
          <TextInput type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
        </Field>
        {error && <p className="text-sm mb-3 text-danger">{error}</p>}
        <Button type="submit" className="w-full" disabled={busy}>
          {busy ? "Entrando…" : "Entrar"}
        </Button>
      </form>

      <div className="mt-5 text-sm flex items-center justify-between">
        <Link href="/olvide-password" className="font-semibold text-primary-light">
          Olvidé mi contraseña
        </Link>
        <Link href="/registro" className="font-semibold text-ink">
          Crear cuenta →
        </Link>
      </div>
    </div>
  );
}
