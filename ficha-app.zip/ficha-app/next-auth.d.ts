import "next-auth";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      role: "USER" | "MODERADOR" | "ADMIN";
      username: string;
      name?: string | null;
      email?: string | null;
    };
  }
}
