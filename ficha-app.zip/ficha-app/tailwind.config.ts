import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        bg: "#0A0B10",
        surface: "#14151F",
        surface2: "#1B1D29",
        border: "#262837",
        ink: "#F4F5F8",
        muted: "#8B8FA3",
        primary: {
          DEFAULT: "#7C5CFC",
          dark: "#6647E0",
          light: "#9B85FF",
        },
        cyan: "#22D3EE",
        success: "#34D399",
        warning: "#FBBF24",
        danger: "#F87171",
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(124,92,252,0.4), 0 8px 24px rgba(124,92,252,0.25)",
      },
    },
  },
  plugins: [],
};
export default config;
