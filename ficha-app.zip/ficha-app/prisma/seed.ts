import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const adminPass = await bcrypt.hash("admin123", 10);
  await prisma.user.upsert({
    where: { username: "admin" },
    update: {},
    create: {
      username: "admin",
      email: "admin@ficha.local",
      passwordHash: adminPass,
      role: "ADMIN",
      profile: {
        create: {
          displayName: "Administrador",
          published: false,
          social: {},
          extraButtons: [],
        },
      },
    },
  });

  const modPass = await bcrypt.hash("mod123", 10);
  await prisma.user.upsert({
    where: { username: "moderador" },
    update: {},
    create: {
      username: "moderador",
      email: "moderador@ficha.local",
      passwordHash: modPass,
      role: "MODERADOR",
      profile: { create: { displayName: "Moderador", published: false, social: {}, extraButtons: [] } },
    },
  });

  await prisma.appConfig.upsert({
    where: { id: 1 },
    update: {},
    create: { id: 1, paymentInfo: "Nequi 3001234567 - Mi Empresa SAS" },
  });

  const samplePass = await bcrypt.hash("demo123", 10);
  const samples = [
    { username: "ropaurbana", displayName: "Ropa Urbana MZ", tagline: "Streetwear hecho en Medellín", plan: "PRO" as const, verified: true },
    { username: "tecnoshop", displayName: "TecnoShop CO", tagline: "Accesorios de tecnología", plan: "BASICO" as const, verified: false },
    { username: "cafeteria_luna", displayName: "Cafetería Luna", tagline: "Café de origen colombiano", plan: "FREE" as const, verified: false },
  ];
  for (const s of samples) {
    await prisma.user.upsert({
      where: { username: s.username },
      update: {},
      create: {
        username: s.username,
        email: `${s.username}@ficha.local`,
        passwordHash: samplePass,
        role: "USER",
        profile: {
          create: {
            displayName: s.displayName,
            tagline: s.tagline,
            description: `Perfil de ejemplo para ${s.displayName}.`,
            verified: s.verified,
            planType: s.plan,
            planStatus: "active",
            social: { whatsapp: { url: "573000000000", visible: true } },
            extraButtons: [],
          },
        },
      },
    });
  }

  console.log("Seed completo: admin/admin123, moderador/mod123, usuarios de ejemplo con contraseña demo123");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
